cp autoaur.py /bin/autoaur
