#!/usr/bin/env python3

import os
import sys

opt = sys.argv[1]

print("Are you sure you want to clone the contents of package {} in this directory? (y/N) ".format(opt))
    
res = input()
    
if res.lower() == "y":
    os.system("git clone https://aur.archlinux.org/{}.git . && less PKGBUILD".format(opt, opt))
    
    print("Do you still want to install this package? (y/N) ")
    res_two = input()
    
    if res_two.lower() == "y":
        os.system("makepkg -si")
