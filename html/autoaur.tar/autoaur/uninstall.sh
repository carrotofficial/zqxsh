rm /bin/autoaur
